"""
granite_client.py
IBM Granite API integration for MatchMind AI.
Handles all LLM calls: match narratives, VAR explanations, tactical briefings.
"""

import os
import json
import time
import requests
from typing import Optional

# ---------------------------------------------------------------------------
# Configuration
# ---------------------------------------------------------------------------

WATSONX_API_URL = os.getenv(
    "WATSONX_API_URL",
    "https://us-south.ml.cloud.ibm.com/ml/v1/text/generation?version=2023-05-29",
)
WATSONX_API_KEY = os.getenv("WATSONX_API_KEY", "")
WATSONX_PROJECT_ID = os.getenv("WATSONX_PROJECT_ID", "")

IAM_TOKEN_URL = "https://iam.cloud.ibm.com/identity/token"

GRANITE_MODEL_ID = "ibm/granite-3-3-8b-instruct"

DEFAULT_PARAMS = {
    "max_new_tokens": 512,
    "min_new_tokens": 50,
    "temperature": 0.7,
    "top_p": 0.9,
    "repetition_penalty": 1.1,
    "stop_sequences": ["<|endoftext|>"],
}


# ---------------------------------------------------------------------------
# IAM Token management
# ---------------------------------------------------------------------------

_token_cache: dict = {"token": None, "expires_at": 0}


def _get_iam_token() -> str:
    """Fetch and cache an IBM IAM bearer token."""
    now = time.time()
    if _token_cache["token"] and now < _token_cache["expires_at"] - 60:
        return _token_cache["token"]

    if not WATSONX_API_KEY:
        raise EnvironmentError(
            "WATSONX_API_KEY is not set. "
            "Add it to your .env file or Streamlit secrets."
        )

    resp = requests.post(
        IAM_TOKEN_URL,
        headers={"Content-Type": "application/x-www-form-urlencoded"},
        data={
            "grant_type": "urn:ibm:params:oauth:grant-type:apikey",
            "apikey": WATSONX_API_KEY,
        },
        timeout=15,
    )
    resp.raise_for_status()
    data = resp.json()

    _token_cache["token"] = data["access_token"]
    _token_cache["expires_at"] = now + data.get("expires_in", 3600)
    return _token_cache["token"]


# ---------------------------------------------------------------------------
# Core generation function
# ---------------------------------------------------------------------------

def generate(
    prompt: str,
    system_prompt: str = "",
    max_new_tokens: int = 512,
    temperature: float = 0.7,
) -> str:
    """
    Send a prompt to IBM Granite via watsonx.ai and return the generated text.

    Args:
        prompt: The user-facing prompt.
        system_prompt: Optional system-level instruction prepended to the prompt.
        max_new_tokens: Maximum tokens to generate.
        temperature: Sampling temperature (0 = deterministic, 1 = creative).

    Returns:
        Generated text string.
    """
    if not WATSONX_PROJECT_ID:
        raise EnvironmentError(
            "WATSONX_PROJECT_ID is not set. "
            "Add it to your .env file or Streamlit secrets."
        )

    token = _get_iam_token()

    # Granite instruction format: <|system|>...<|user|>...<|assistant|>
    if system_prompt:
        full_prompt = (
            f"<|system|>\n{system_prompt}\n"
            f"<|user|>\n{prompt}\n"
            f"<|assistant|>\n"
        )
    else:
        full_prompt = f"<|user|>\n{prompt}\n<|assistant|>\n"

    payload = {
        "model_id": GRANITE_MODEL_ID,
        "project_id": WATSONX_PROJECT_ID,
        "input": full_prompt,
        "parameters": {
            **DEFAULT_PARAMS,
            "max_new_tokens": max_new_tokens,
            "temperature": temperature,
        },
    }

    headers = {
        "Authorization": f"Bearer {token}",
        "Content-Type": "application/json",
        "Accept": "application/json",
    }

    resp = requests.post(
        WATSONX_API_URL,
        headers=headers,
        json=payload,
        timeout=60,
    )
    resp.raise_for_status()
    result = resp.json()

    generated = result["results"][0]["generated_text"].strip()
    return generated


# ---------------------------------------------------------------------------
# Domain-specific generation helpers
# ---------------------------------------------------------------------------

_MATCH_SYSTEM = (
    "You are MatchMind AI, an expert soccer analyst and tactical commentator. "
    "You explain football matches in clear, engaging language accessible to any fan, "
    "from a complete beginner to a seasoned supporter. "
    "Always ground your analysis in specific stats provided. "
    "Never make up scores or facts not in the prompt. "
    "Respond in structured plain English — no markdown headers, no bullet soup. "
    "Write like a Guardian football correspondent: authoritative, warm, precise."
)

_VAR_SYSTEM = (
    "You are a FIFA Laws of the Game expert and VAR (Video Assistant Referee) specialist. "
    "You explain officiating decisions using the exact language and logic of the Laws. "
    "Be impartial, precise, and educational. "
    "When Laws text is provided as context, quote the relevant article directly. "
    "If a decision is genuinely debatable, say so and explain both sides. "
    "Keep explanations clear enough for a fan with no officiating background."
)

_TACTICAL_SYSTEM = (
    "You are a UEFA Pro Licence tactical analyst. "
    "You break down formations, pressing triggers, transitions, and set-piece routines "
    "in language that is vivid and specific — think Michael Cox or Jonathan Wilson. "
    "Ground all analysis in the team stats and context provided. "
    "Never be vague. Every claim should connect to a concrete stat or observable pattern."
)


def explain_prematch(
    team_a: str,
    team_b: str,
    stats_a: dict,
    stats_b: dict,
    is_neutral: bool,
    is_major: bool,
    probabilities: dict,
) -> str:
    """Generate a pre-match tactical briefing."""
    context = f"""
Match: {team_a} vs {team_b}
Venue: {"Neutral" if is_neutral else f"{team_a} home advantage"}
Tournament: {"Major tournament (World Cup / Euros)" if is_major else "Friendly / qualifier"}

{team_a} stats:
  Win rate:       {stats_a['winrate']:.1%}
  Goals per game: {stats_a['goal_avg']:.2f}
  Recent form:    {stats_a['recent_form']:.1%} (last 10 matches)
  Matches played: {stats_a['matches_played']}

{team_b} stats:
  Win rate:       {stats_b['winrate']:.1%}
  Goals per game: {stats_b['goal_avg']:.2f}
  Recent form:    {stats_b['recent_form']:.1%} (last 10 matches)
  Matches played: {stats_b['matches_played']}

AI predicted probabilities:
  {team_a} win: {probabilities['team_a_win_prob']:.1%}
  Draw:         {probabilities['draw_prob']:.1%}
  {team_b} win: {probabilities['team_b_win_prob']:.1%}
"""
    prompt = (
        f"Write a pre-match tactical briefing for {team_a} vs {team_b}. "
        f"Cover: (1) what the stats reveal about each team's style and current form, "
        f"(2) the key tactical battle that will likely decide the match, "
        f"(3) which team the AI model favours and why that makes sense given the numbers. "
        f"Keep it to 3 focused paragraphs.\n\nContext:\n{context}"
    )
    return generate(prompt, system_prompt=_MATCH_SYSTEM, max_new_tokens=450, temperature=0.72)


def explain_var_decision(
    situation: str,
    decision: str,
    laws_context: str = "",
) -> str:
    """Generate a plain-English VAR ruling explanation."""
    context_block = f"\nRelevant Laws of the Game extract:\n{laws_context}\n" if laws_context else ""
    prompt = (
        f"A VAR check has just been completed.\n\n"
        f"Situation: {situation}\n"
        f"Decision: {decision}\n"
        f"{context_block}\n"
        f"Explain: (1) exactly what the VAR team checked and why, "
        f"(2) what the Laws say about this situation, "
        f"(3) whether the decision was correct and why fans might find it controversial. "
        f"Be direct. Cite the Law number if provided in context."
    )
    return generate(prompt, system_prompt=_VAR_SYSTEM, max_new_tokens=500, temperature=0.5)


def explain_tactical_shift(
    team: str,
    before_formation: str,
    after_formation: str,
    match_context: str,
    stats: dict,
) -> str:
    """Explain why a tactical substitution or formation change was made."""
    prompt = (
        f"{team} changed shape from {before_formation} to {after_formation}.\n\n"
        f"Match context: {match_context}\n"
        f"Team stats: win rate {stats['winrate']:.1%}, "
        f"avg goals {stats['goal_avg']:.2f}, "
        f"recent form {stats['recent_form']:.1%}.\n\n"
        f"Explain: (1) what problem the manager was trying to solve, "
        f"(2) what the new shape offers in terms of pressing, width, or transitions, "
        f"(3) the risk this change introduces. "
        f"2–3 paragraphs, specific and analytical."
    )
    return generate(prompt, system_prompt=_TACTICAL_SYSTEM, max_new_tokens=420, temperature=0.68)


def explain_momentum_shift(
    team_a: str,
    team_b: str,
    event: str,
    minute: int,
    match_state: str,
) -> str:
    """Explain a momentum shift event during a match."""
    prompt = (
        f"At minute {minute} of {team_a} vs {team_b}, the following happened: {event}.\n"
        f"Match state at that point: {match_state}.\n\n"
        f"Explain how this moment shifts momentum: what changes for each team "
        f"psychologically and tactically, and what we should expect in the minutes that follow. "
        f"2 paragraphs."
    )
    return generate(prompt, system_prompt=_MATCH_SYSTEM, max_new_tokens=350, temperature=0.75)


# ---------------------------------------------------------------------------
# Credential validation helper
# ---------------------------------------------------------------------------

def validate_credentials() -> tuple[bool, str]:
    """
    Check whether watsonx credentials are configured and valid.
    Returns (ok: bool, message: str).
    """
    if not WATSONX_API_KEY:
        return False, "WATSONX_API_KEY is missing."
    if not WATSONX_PROJECT_ID:
        return False, "WATSONX_PROJECT_ID is missing."
    try:
        _get_iam_token()
        return True, "Credentials valid."
    except requests.HTTPError as e:
        return False, f"Authentication failed: {e.response.status_code} {e.response.text[:200]}"
    except Exception as e:
        return False, f"Error: {e}"
